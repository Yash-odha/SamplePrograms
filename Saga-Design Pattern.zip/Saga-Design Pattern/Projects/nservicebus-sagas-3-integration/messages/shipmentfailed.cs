﻿using NServiceBus;

namespace Shipping
{
    public class ShipmentFailed : IEvent
    {
    }
}