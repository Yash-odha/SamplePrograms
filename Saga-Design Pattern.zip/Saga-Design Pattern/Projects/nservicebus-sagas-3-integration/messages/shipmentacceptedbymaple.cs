﻿using NServiceBus;

namespace Messages
{
    public class ShipmentAcceptedByMaple : IMessage
    {
    }
}