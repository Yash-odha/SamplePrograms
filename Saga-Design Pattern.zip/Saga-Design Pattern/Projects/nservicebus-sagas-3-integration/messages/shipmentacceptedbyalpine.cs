﻿using NServiceBus;

namespace Messages
{
    public class ShipmentAcceptedByAlpine : IMessage
    {
    }
}