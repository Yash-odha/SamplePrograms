namespace Shared.Contracts
{
    public class PaymentCompletedEvent
    {
        public int OrderId { get; set; }
    }
}