﻿public class MyResponse
{
}