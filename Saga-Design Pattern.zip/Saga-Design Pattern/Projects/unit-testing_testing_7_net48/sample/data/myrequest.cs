﻿public class MyRequest
{
}