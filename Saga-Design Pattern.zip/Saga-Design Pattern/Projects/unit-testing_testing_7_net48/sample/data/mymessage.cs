﻿public class MyMessage
{
}